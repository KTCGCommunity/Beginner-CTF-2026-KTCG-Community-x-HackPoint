// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {MockERC20} from "./MockERC20.sol";

contract VaultPool {
    uint256 public constant AUTHORIZED_AMOUNT = 100 ether;
    uint256 public constant SOLVE_THRESHOLD = 1000 ether;

    address public immutable signer;
    MockERC20 public immutable token;

    constructor(address _signer, address _token) {
        signer = _signer;
        token = MockERC20(_token);
    }

    function withdraw(address to, uint256 amount, bytes calldata sig) external {
        require(msg.sender == to, "only recipient");
        bytes32 inner = keccak256(abi.encodePacked("Withdraw", to, amount));
        bytes32 ethHash = keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", inner));
        require(_recover(ethHash, sig) == signer, "bad sig");
        require(token.transfer(to, amount), "transfer");
    }

    function isSolved(address player) external view returns (bool) {
        return token.balanceOf(player) >= SOLVE_THRESHOLD;
    }

    function _recover(bytes32 h, bytes calldata sig) internal pure returns (address) {
        require(sig.length == 65, "sig length");
        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly {
            r := calldataload(sig.offset)
            s := calldataload(add(sig.offset, 0x20))
            v := byte(0, calldataload(add(sig.offset, 0x40)))
        }
        if (v < 27) v += 27;
        return ecrecover(h, v, r, s);
    }
}
