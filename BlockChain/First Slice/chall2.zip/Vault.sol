// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {MockERC20} from "./MockERC20.sol";

contract Vault {
    MockERC20 public immutable asset;
    uint256 public totalShares;
    mapping(address => uint256) public shareOf;

    constructor(address _asset) {
        asset = MockERC20(_asset);
    }

    function totalAssets() public view returns (uint256) {
        return asset.balanceOf(address(this));
    }

    function deposit(uint256 amount) external returns (uint256 shares) {
        uint256 _ta = totalAssets();
        uint256 _ts = totalShares;
        if (_ts == 0) {
            shares = amount;
        } else {
            shares = (amount * _ts) / _ta;
        }
        require(asset.transferFrom(msg.sender, address(this), amount), "tf");
        shareOf[msg.sender] += shares;
        totalShares = _ts + shares;
    }

    function withdraw(uint256 shares) external returns (uint256 amount) {
        uint256 _ts = totalShares;
        amount = (shares * totalAssets()) / _ts;
        shareOf[msg.sender] -= shares;
        totalShares = _ts - shares;
        require(asset.transfer(msg.sender, amount), "t");
    }
}
