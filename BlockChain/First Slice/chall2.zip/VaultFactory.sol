// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {Setup} from "./Setup.sol";

contract VaultFactory {
    mapping(address => Setup) public setupOf;

    event Spawned(address indexed player, address indexed setup);

    function spawn() external returns (Setup) {
        require(address(setupOf[msg.sender]) == address(0), "already spawned");
        Setup s = new Setup(msg.sender);
        setupOf[msg.sender] = s;
        emit Spawned(msg.sender, address(s));
        return s;
    }

    function isSolved(address player) external view returns (bool) {
        Setup s = setupOf[player];
        if (address(s) == address(0)) return false;
        return s.isSolved();
    }
}
