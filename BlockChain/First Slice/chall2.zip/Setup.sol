// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {MockERC20} from "./MockERC20.sol";
import {Vault} from "./Vault.sol";
import {Depositor} from "./Depositor.sol";

contract Setup {
    uint256 public constant PLAYER_BALANCE = 2000 ether;
    uint256 public constant VICTIM_BALANCE = 1000 ether;
    uint256 public constant SOLVE_THRESHOLD = 2500 ether;

    address public immutable player;
    MockERC20 public immutable asset;
    Vault public immutable vault;
    Depositor public immutable depositor;

    constructor(address _player) {
        player = _player;

        MockERC20 t = new MockERC20("MockUSDC", "USDC", PLAYER_BALANCE + VICTIM_BALANCE);
        Vault v = new Vault(address(t));
        Depositor d = new Depositor(_player, address(v), address(t));

        require(t.transfer(_player, PLAYER_BALANCE), "fund player");
        require(t.transfer(address(d), VICTIM_BALANCE), "fund victim");

        asset = t;
        vault = v;
        depositor = d;
    }

    function isSolved() external view returns (bool) {
        return depositor.triggered() && asset.balanceOf(player) >= SOLVE_THRESHOLD;
    }
}
