// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {MockERC20} from "./MockERC20.sol";
import {Vault} from "./Vault.sol";

contract Depositor {
    uint256 public constant AMOUNT = 1000 ether;

    address public immutable player;
    Vault public immutable vault;
    MockERC20 public immutable asset;
    bool public triggered;

    constructor(address _player, address _vault, address _asset) {
        player = _player;
        vault = Vault(_vault);
        asset = MockERC20(_asset);
        MockERC20(_asset).approve(_vault, type(uint256).max);
    }

    function triggerVictimDeposit() external {
        require(msg.sender == player, "only player");
        require(!triggered, "already");
        vault.deposit(AMOUNT);
        triggered = true;
    }
}
