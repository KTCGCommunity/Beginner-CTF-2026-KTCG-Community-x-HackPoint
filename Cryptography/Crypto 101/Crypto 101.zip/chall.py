import socket
import random
import base64
import codecs
import signal
import sys
from typing import Tuple, List, Callable

FLAG = open("flag.txt").read().strip()

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'
    MAGENTA = '\033[35m'

BANNER = f"""
{Colors.CYAN}{Colors.BOLD}
   ╔══════════════════════════════════════════════════════════════╗
   ║                                                              ║
   ║     ██████╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗        ║
   ║    ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗       ║
   ║    ██║     ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║       ║
   ║    ██║     ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║       ║
   ║    ╚██████╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝       ║
   ║     ╚═════╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝        ║
   ║                                                              ║
   ║     ██████╗ ██████╗ ███╗   ███╗███████╗██╗   ██╗███████╗     ║
   ║    ██╔════╝██╔═══██╗████╗ ████║██╔════╝██║   ██║██╔════╝     ║
   ║    ██║     ██║   ██║██╔████╔██║█████╗  ██║   ██║███████╗     ║
   ║    ██║     ██║   ██║██║╚██╔╝██║██╔══╝  ╚██╗ ██╔╝╚════██║     ║
   ║    ╚██████╗╚██████╔╝██║ ╚═╝ ██║██║      ╚████╔╝ ███████║     ║
   ║     ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚═╝       ╚═══╝  ╚══════╝     ║
   ║                                                              ║
   ║         {Colors.YELLOW}★  Jawab 5 soal crypto dengan benar  ★{Colors.CYAN}               ║
   ║         {Colors.MAGENTA}★      Dapatkan flag nya sekarang!   ★{Colors.CYAN}               ║
   ║                                                              ║
   ╚══════════════════════════════════════════════════════════════╝{Colors.END}
"""

def sanitize_input(data: bytes) -> str:
    """Clean and decode user input"""
    return data.decode().strip().lower()

def send_message(conn: socket.socket, message: str, color: str = "") -> None:
    """Safely send a colored message to client"""
    try:
        if color:
            conn.sendall(f"{color}{message}{Colors.END}".encode())
        else:
            conn.sendall(message.encode())
    except (socket.error, BrokenPipeError):
        pass

class QuestionGenerator:
    @staticmethod
    def gen_caesar() -> Tuple[str, str]:
        words = ["helloworld", "cryptography", "security", "challenge", "python"]
        pt = random.choice(words)
        shift = random.randint(1, 25)
        ct = ''.join(chr((ord(c) - ord('a') + shift) % 26 + ord('a')) for c in pt)
        return (
            f"{Colors.YELLOW}Caesar cipher{Colors.END} dengan shift {Colors.CYAN}{shift}{Colors.END}:\n"
            f"  {Colors.GREEN}'{ct}'{Colors.END}\n"
            f"{Colors.BOLD}Decode hasilnya{Colors.END}: ",
            pt
        )

    @staticmethod
    def gen_rot13() -> Tuple[str, str]:
        words = ["reverse", "encode", "hidden", "secret", "cipher"]
        pt = random.choice(words)
        ct = codecs.encode(pt, 'rot_13')
        return (
            f"{Colors.YELLOW}ROT13{Colors.END} dari:\n"
            f"  {Colors.GREEN}'{ct}'{Colors.END}\n"
            f"{Colors.BOLD}Decode hasilnya{Colors.END}: ",
            pt
        )

    @staticmethod
    def gen_base64_decode() -> Tuple[str, str]:
        words = ["flagtime", "opensesame", "hacktheplanet", "byteforce", "welcome"]
        pt = random.choice(words)
        ct = base64.b64encode(pt.encode()).decode()
        return (
            f"{Colors.YELLOW}Base64{Colors.END} berikut jika di-decode menjadi apa?\n"
            f"  {Colors.GREEN}'{ct}'{Colors.END}\n"
            f"{Colors.BOLD}Jawab{Colors.END}: ",
            pt
        )

    @staticmethod
    def gen_base64_encode() -> Tuple[str, str]:
        words = ["dragon", "matrix", "exploit", "kernel", "binary"]
        pt = random.choice(words)
        ct = base64.b64encode(pt.encode()).decode()
        return (
            f"Encode kata berikut ke {Colors.YELLOW}Base64{Colors.END}:\n"
            f"  {Colors.GREEN}'{pt}'{Colors.END}\n"
            f"{Colors.BOLD}Jawab{Colors.END}: ",
            ct
        )

    @staticmethod
    def gen_hex_decode() -> Tuple[str, str]:
        words = ["ghost", "packet", "socket", "buffer", "stack"]
        pt = random.choice(words)
        ct = pt.encode().hex()
        return (
            f"{Colors.YELLOW}Hex{Colors.END} berikut jika di-decode menjadi apa?\n"
            f"  {Colors.GREEN}'{ct}'{Colors.END}\n"
            f"{Colors.BOLD}Jawab{Colors.END}: ",
            pt
        )

    @staticmethod
    def gen_hex_encode() -> Tuple[str, str]:
        words = ["flag", "nonce", "block", "hash", "salt"]
        pt = random.choice(words)
        ct = pt.encode().hex()
        return (
            f"Encode kata berikut ke {Colors.YELLOW}Hex{Colors.END}:\n"
            f"  {Colors.GREEN}'{pt}'{Colors.END}\n"
            f"{Colors.BOLD}Jawab{Colors.END}: ",
            ct
        )

    @staticmethod
    def gen_xor() -> Tuple[str, str]:
        words = ["attack", "defend", "breach", "access", "bypass"]
        pt = random.choice(words)
        key = random.randint(1, 15)
        ct = ''.join(format(ord(c) ^ key, '02x') for c in pt)
        return (
            f"{Colors.YELLOW}XOR{Colors.END} tiap karakter dengan {Colors.CYAN}key={key}{Colors.END}, hasilnya (hex):\n"
            f"  {Colors.GREEN}'{ct}'{Colors.END}\n"
            f"{Colors.BOLD}Decode ke plaintext{Colors.END}: ",
            pt
        )

GENERATORS: List[Callable[[], Tuple[str, str]]] = [
    QuestionGenerator.gen_caesar,
    QuestionGenerator.gen_rot13,
    QuestionGenerator.gen_base64_decode,
    QuestionGenerator.gen_base64_encode,
    QuestionGenerator.gen_hex_decode,
    QuestionGenerator.gen_hex_encode,
    QuestionGenerator.gen_xor,
]

class ChallengeHandler:
    def __init__(self, conn: socket.socket, addr: Tuple[str, int]):
        self.conn = conn
        self.addr = addr
        self.score = 0
        self.questions_count = 5
        
    def send(self, message: str, color: str = "") -> None:
        """Send message to client"""
        send_message(self.conn, message, color)
    
    def send_success(self, message: str) -> None:
        """Send success message"""
        self.send(f"{Colors.GREEN}{message}{Colors.END}\n")
    
    def send_error(self, message: str) -> None:
        """Send error message"""
        self.send(f"{Colors.RED}{message}{Colors.END}\n")
    
    def send_info(self, message: str) -> None:
        """Send info message"""
        self.send(f"{Colors.CYAN}{message}{Colors.END}\n")
    
    def receive(self, timeout: int = 30) -> str:
        """Receive input from client with timeout"""
        try:
            self.conn.settimeout(timeout)
            self.send(f"{Colors.BOLD}> {Colors.END}", "")
            data = self.conn.recv(1024)
            return sanitize_input(data)
        except socket.timeout:
            self.send_error("\n[-] Timeout! Terlalu lama menjawab.\n")
            return ""
        except Exception:
            return ""
    
    def show_progress(self, current: int) -> None:
        """Show progress bar"""
        progress = int((current / self.questions_count) * 40)
        bar = "█" * progress + "░" * (40 - progress)
        self.send(f"\n{Colors.MAGENTA}📊 Progress: [{bar}] {current}/{self.questions_count}{Colors.END}\n")
    
    def run(self) -> bool:
        """Run the challenge session"""
        try:
            self.send(BANNER)
            self.send_info("\n✨ Selamat datang di Crypto 101! ✨\n")
            
            selected = random.sample(GENERATORS, self.questions_count)
            
            for i, gen in enumerate(selected):
                self.show_progress(i)
                
                self.send(f"\n{Colors.YELLOW}{Colors.BOLD}┌─[ Soal {i+1}/{self.questions_count} ]────────────────────────────────────────┐{Colors.END}\n")
                
                question, answer = gen()
                self.send(question)
                
                jawaban = self.receive()
                
                if not jawaban:
                    self.send_error("\n└─[ GAGAL ]────────────────────────────────────────────┘\n")
                    return False
                
                if jawaban == answer.lower():
                    self.send_success(f"\n└─[ ✓ BENAR ]───────────────────────────────────────────┘")
                    self.score += 1
                else:
                    self.send_error(f"\n└─[ ✗ SALAH ]───────────────────────────────────────────┘")
                    self.send_error(f"\n    ❌ Jawaban kamu salah!\n")
                    self.send_info(f"    💡 Petunjuk: Coba pelajari lagi teknik kriptografi yang digunakan.\n")
                    self.send_error(f"\n[!] Gagal. Silahkan coba lagi dari awal!\n")
                    return False
            
            self.show_progress(self.questions_count)
            self.send(f"\n{Colors.GREEN}{Colors.BOLD}")
            self.send("╔══════════════════════════════════════════════════════════════╗\n")
            self.send("║                      🎉  SELAMAT!  🎉                        ║\n")
            self.send("║                                                              ║\n")
            self.send("║        Kamu berhasil menjawab semua soal dengan benar!       ║\n")
            self.send("║                                                              ║\n")
            self.send(f"║        {Colors.YELLOW}✨ FLAG KAMU: ✨{Colors.GREEN}                                      ║\n")
            self.send("║                                                              ║\n")
            self.send(f"║   {Colors.CYAN}{FLAG}{Colors.GREEN}                       ║\n")
            self.send("║                                                              ║\n")
            self.send("╚══════════════════════════════════════════════════════════════╝\n")
            self.send(f"{Colors.END}")
            return True
            
        except Exception as e:
            print(f"Error handling {self.addr}: {e}")
            return False
        finally:
            try:
                self.conn.close()
            except:
                pass

def handle(conn: socket.socket, addr: Tuple[str, int]) -> None:
    """Handle client connection"""
    print(f"{Colors.GREEN}[+]{Colors.END} Connection from {Colors.CYAN}{addr[0]}:{addr[1]}{Colors.END}")
    handler = ChallengeHandler(conn, addr)
    handler.run()
    print(f"{Colors.RED}[-]{Colors.END} Connection closed from {Colors.CYAN}{addr[0]}{Colors.END}")

def signal_handler(sig, frame):
    """Handle Ctrl+C gracefully"""
    print(f"\n{Colors.YELLOW}[*] Shutting down server...{Colors.END}")
    sys.exit(0)

def main():
    HOST, PORT = "0.0.0.0", 8080
    
    # Setup signal handler
    signal.signal(signal.SIGINT, signal_handler)
    
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            s.bind((HOST, PORT))
            s.listen(10)
            print(f"{Colors.CYAN}{Colors.BOLD}")
            print("╔══════════════════════════════════════════════════════════════╗")
            print("║                                                              ║")
            print("║         🚀  CRYPTO 101 SERVER IS RUNNING  🚀                 ║")
            print("║                                                              ║")
            print(f"║     {Colors.YELLOW}📍 Host: {HOST}{Colors.CYAN}                                    ║")
            print(f"║     {Colors.YELLOW}🔌 Port: {PORT}{Colors.CYAN}                                        ║")
            print("║                                                              ║")
            print(f"║     {Colors.GREEN}🎮 Connect with: nc {HOST} {PORT}{Colors.CYAN}                     ║")
            print("║                                                              ║")
            print("║     ⚡ Press Ctrl+C to stop the server                       ║")
            print("║                                                              ║")
            print("╚══════════════════════════════════════════════════════════════╝")
            print(f"{Colors.END}")
            
            while True:
                try:
                    conn, addr = s.accept()
                    handle(conn, addr)
                except KeyboardInterrupt:
                    raise
                except Exception as e:
                    print(f"{Colors.RED}[!] Error accepting connection: {e}{Colors.END}")
                    continue
                    
        except OSError as e:
            print(f"{Colors.RED}[!] Failed to bind to port {PORT}: {e}{Colors.END}")
            print(f"{Colors.RED}[!] Make sure port {PORT} is available{Colors.END}")
            sys.exit(1)

if __name__ == "__main__":
    main()
