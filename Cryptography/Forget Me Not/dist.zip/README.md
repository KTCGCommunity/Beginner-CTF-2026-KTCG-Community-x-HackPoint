# Forget Me Not Challenge Docker

## Build

```bash
docker compose build
```

## Run

```bash
docker compose up -d
```

## Test locally

```bash
nc localhost 31337
```
