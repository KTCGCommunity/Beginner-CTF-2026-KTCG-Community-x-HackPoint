#!/bin/sh
set -eu

PORT="${PORT:-1337}"
TIMEOUT="${TIMEOUT:-120}"

exec socat -T "$TIMEOUT" TCP-LISTEN:"$PORT",reuseaddr,fork EXEC:"python3 -u /home/ctf/chall.py",stderr
