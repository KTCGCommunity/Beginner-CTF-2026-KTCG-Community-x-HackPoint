#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
void (*fungsi_sistem)();
void setup() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}
void ret2win() {
    FILE *f = fopen("flag.txt", "r");
    if (f == NULL) {
        puts("[!] Kesalahan: File flag.txt tidak ditemukan!");
        exit(0);
    }
    char flag[128];
    fgets(flag, sizeof(flag), f);
    printf("\n[+] Akses Dimensi Rahasia Terbuka!\n");
    printf("[+] FLAG: %s\n", flag);
    fclose(f);
    exit(0);
}
void sapa_user() {
    puts("[*] Sistem Brankas Aktif...");
}
char *brankas[10];
int ukuran[10];
char *dimensi_lain = NULL;
int ukuran_dimensi = 0;
void menu() {
    puts("\n=== BRANKAS PARADOKS ===");
    puts("1. Simpan Barang");
    puts("2. Ubah Barang");
    puts("3. Lempar ke Dimensi Lain (Buang)");
    puts("4. Tarik dari Dimensi Lain");
    puts("5. Keluar");
    printf("Pilihan: ");
}
void simpan() {
    int idx, size;
    printf("Index (0-9): ");
    scanf("%d", &idx);
    if(idx < 0 || idx > 9) return;

    printf("Ukuran (maks 120): ");
    scanf("%d", &size);
    if(size <= 0 || size > 120) {
        puts("Ukuran tidak valid!");
        return;
    }
    brankas[idx] = (char*)malloc(size);
    ukuran[idx] = size;
    printf("Isi barang: ");
    read(0, brankas[idx], size);
}
void ubah() {
    int idx;
    printf("Index (0-9): ");
    scanf("%d", &idx);
    if(idx < 0 || idx > 9 || !brankas[idx]) {
        puts("Slot kosong atau tidak valid!");
        return;
    }
    printf("Isi baru: ");
    read(0, brankas[idx], ukuran[idx]);
}
void lempar() {
    int idx;
    printf("Index (0-9): ");
    scanf("%d", &idx);
    if(idx < 0 || idx > 9 || !brankas[idx]) return;
    free(brankas[idx]);
    dimensi_lain = brankas[idx];
    ukuran_dimensi = ukuran[idx];
    brankas[idx] = NULL;
    ukuran[idx] = 0;
    puts("Barang dilempar ke dimensi lain!");
}
void tarik() {
    int idx;
    printf("Index (0-9): ");
    scanf("%d", &idx);
    if(idx < 0 || idx > 9) return;
    if(!dimensi_lain) {
        puts("Dimensi lain kosong!");
        return;
    }

    brankas[idx] = dimensi_lain;
    ukuran[idx] = ukuran_dimensi;

    dimensi_lain = NULL;
    ukuran_dimensi = 0;
    puts("Barang berhasil ditarik kembali! (Apakah wujudnya masih sama?)");
}
int main() {
    setup();
    fungsi_sistem = sapa_user;
    int opt;
    while(1) {
        fungsi_sistem();
        menu();
        if(scanf("%d", &opt) != 1) break;
        switch(opt) {
            case 1: simpan(); break;
            case 2: ubah(); break;
            case 3: lempar(); break;
            case 4: tarik(); break;
            case 5: exit(0);
            default: puts("Pilihan salah!");
        }
    }
    return 0;
}
