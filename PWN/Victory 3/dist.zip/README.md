# Victory 3

Looks like u guys already completed the previous one yea? I created this last one. Maybe the victory u're looking for already randomized but it's okay lmao. Too ez for yall. 

Connect : nc ctf.try4gain.web.id 10023

## Run local

```bash
docker compose up -d --build
nc 127.0.0.1 10023
```