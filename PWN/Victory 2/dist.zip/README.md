# Victory 2

Remember Victory? Yea that sh*tty ahh game who said needs pure luck but no luck used at all? Try the sequel, it's better (I guess...)

Connect : nc ctf.try4gain.web.id 10022

## Run local

```bash
docker compose up -d --build
nc 127.0.0.1 10021
```