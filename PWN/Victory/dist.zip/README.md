# Victory

Everybody want to get a victory in every game they've played. But how do you win a game with pure luck? 

Connect : nc ctf.try4gain.web.id 10021

## Build and Run in Local

```bash
docker compose up -d --build
nc 127.0.0.1 10021
```

Flag :

```text
KTCG{flag_buat_lokal_yh}
```