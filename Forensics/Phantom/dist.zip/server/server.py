import socket
import json
import sys
import signal

# ANSI Color Codes
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
WHITE = '\033[97m'
BOLD = '\033[1m'
RESET = '\033[0m'

FLAG = open("flag.txt").read().strip()
ANSWERS = json.load(open("answers.json"))

QUESTIONS = [
    ("q1", f"{CYAN}[{RESET}{BOLD}Q1{RESET}{CYAN}]{RESET} Apa IP address internal yang melakukan koneksi mencurigakan ke server eksternal?\n> {YELLOW}{BOLD}"),
    ("q2", f"{CYAN}[{RESET}{BOLD}Q2{RESET}{CYAN}]{RESET} Apa domain yang di-query lewat DNS oleh host tersebut?\n> {YELLOW}{BOLD}"),
    ("q3", f"{CYAN}[{RESET}{BOLD}Q3{RESET}{CYAN}]{RESET} Apa IP address tujuan dari C2 server?\n> {YELLOW}{BOLD}"),
    ("q4", f"{CYAN}[{RESET}{BOLD}Q4{RESET}{CYAN}]{RESET} Port berapa yang digunakan sebagai tujuan koneksi TCP mencurigakan?\n> {YELLOW}{BOLD}"),
    ("q5", f"{CYAN}[{RESET}{BOLD}Q5{RESET}{CYAN}]{RESET} Ada data tersembunyi di salah satu HTTP header. Decode dan kirimkan isinya.\n> {YELLOW}{BOLD}"),
]

BANNER = f"""
{BOLD}{CYAN}╔══════════════════════════════════════════════════════════════╗{RESET}
{BOLD}{CYAN}║                 PHANTOM PACKET - FORENSIC CHALLENGE          ║{RESET}
{BOLD}{CYAN}║                                                              ║{RESET}
{BOLD}{CYAN}║     Analisis file suspicious.pcap dan jawab 5 pertanyaan     ║{RESET}
{BOLD}{CYAN}║                   di bawah ini dengan benar!                 ║{RESET}
{BOLD}{CYAN}║                                                              ║{RESET}
{BOLD}{CYAN}║  {WHITE}📁 File{RESET}{BOLD}{CYAN}: suspicious.pcap                                    ║{RESET}
{BOLD}{CYAN}║  {WHITE}🎯 Goal{RESET}{BOLD}{CYAN}: Temukan 5 Jawaban Yang Benar                       ║{RESET}
{BOLD}{CYAN}╚══════════════════════════════════════════════════════════════╝{RESET}

"""

def handle_client(conn):
    conn.sendall(BANNER.encode())
    score = 0

    for key, question in QUESTIONS:
        conn.sendall(question.encode())
        try:
            answer = conn.recv(1024).decode().strip()
        except:
            conn.close()
            return

        if answer.lower() == ANSWERS[key].lower():
            conn.sendall(f"{GREEN}[+] Benar!{RESET}\n\n".encode())
            score += 1
        else:
            conn.sendall(f"{RED}[-] Salah!{RESET}\n".encode())
            conn.sendall(f"{RED}[!] Koneksi ditutup. Silakan coba lagi.{RESET}\n".encode())
            conn.close()
            return

    if score == len(QUESTIONS):
        conn.sendall(f"\n{BOLD}{GREEN}╔══════════════════════════════════════════════════════════════╗{RESET}\n".encode())
        conn.sendall(f"{BOLD}{GREEN}║                       🎉 SEMUA BENAR! 🎉                       ║{RESET}\n".encode())
        conn.sendall(f"{BOLD}{GREEN}╚══════════════════════════════════════════════════════════════╝{RESET}\n".encode())
        conn.sendall(f"\n{BOLD}{CYAN}Berikut flag Anda:{RESET}\n".encode())
        conn.sendall(f"{YELLOW}{BOLD}{FLAG}{RESET}\n".encode())
        conn.close()

def signal_handler(sig, frame):
    print(f"\n{RED}[*] Shutting down server...{RESET}")
    sys.exit(0)

def main():
    HOST, PORT = "0.0.0.0", 9001
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, PORT))
        s.listen(10)
        print(f"{GREEN}[*] Server listening on {HOST}:{PORT}{RESET}")
        print(f"{CYAN}[*] Answers loaded: {list(ANSWERS.keys())}{RESET}")
        
        while True:
            try:
                conn, addr = s.accept()
                print(f"{YELLOW}[+] Connection from {addr[0]}:{addr[1]}{RESET}")
                handle_client(conn)
            except Exception as e:
                print(f"{RED}[-] Error: {e}{RESET}")

if __name__ == "__main__":
    main()
